a = 1
print(type(a))
print(isinstance(12,int))
print(isinstance(a,object))
print(isinstance(print(),object))
print(id(a))
b = 5
print(id(b))
print(id(print()))
x = y = 276
print(x)
print(y)
print(id(x))
print(id(y))
print(x == y)
print(x is y)
x = 275
print(id(x))
# list
z = r = [1,2,3,4]
print(z is r)
z.append(5)
print(z)
print(r)
print(r.pop())
print(z)



