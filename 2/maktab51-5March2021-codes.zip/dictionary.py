dict1 = {'key':'value'}
print(dict1)
print(dict1['key'])
dict1['name'] = 'meimanat'
print(dict1)
dict1['age'] = 30
dict1[100] = (1,0)
print(dict1)
dict1[(1,2)] = 10
print(dict1)
dict1['age'] = [12,13]
print(dict1)
students0 = ['mehrnaz','forough','zahra']
studentlist = [{'name':'mehrnaz','class':'python','code':2},
           {'name':'forough','class':'python','code':1},
           {'name':'zahra','class':'python','code':0}]
print(studentlist)
print('######')
for student in studentlist:
    print(student['name'])
print(studentlist[0].keys())
print(studentlist[0].values())

student_dict = studentlist[0]
print(student_dict)
for k,v in student_dict.items():
    print('key is: ',k , 'value is:',v)