for letter in 'aeiou':
    print('vowel: ',letter)

for i in range(10):
    print(i,end=',')


for i in range(0,10):
    print(i,end=',')

for i in range(0,10,2):
    print(i,end=',')
