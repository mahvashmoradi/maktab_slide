<?php
$x = $_POST['num1'];
$y = $_POST['num2'];
echo $x+$y;

?>